//Name: Dhruv Barad
//CSCI 1913 Fall 2021
//Project 3 Final
public class HuffmanNode {
    private HuffmanNode one;    //one node
    private HuffmanNode zero;   //zero node
    private Character data;     //node's data

    /**
     * Constructor for Huffman Node (an internal node)
     */
    public HuffmanNode(HuffmanNode zero, HuffmanNode one) {
        this.zero = zero;   //zero node is not null
        this.one = one;     //one node is not null
        this.data = null;   //data is null
    }

    /**
     * Constructor for Huffman Node ( a leaf node)
     */
    public HuffmanNode(char data) {
        this.data = data;   //data is not null
        this.one = null;    //one node is null
        this.zero = null;   ///zero node is null
    }

    /**
     * Getter for zero node
     * @return - node
     */
    public HuffmanNode getZero() {
        return zero;    //get a node's zero node
    }

    /**
     * Getter for one node
     * @return - node
     */
    public HuffmanNode getOne() {
        return one;     //get a node's one node
    }

    /**
     * Setter for zero node
     * @param zero - a node
     */
    public void setZero(HuffmanNode zero) {
        this.zero = zero;   //set a node's zero node
    }

    /**
     * Setter for one node
     * @param one - a node
     */
    public void setOne(HuffmanNode one) {
        this.one = one;     //set a node's one node
    }

    /**
     * Getter for data
     * @return - a character
     */
    public Character getData() {
        return data;    //get a node's data
    }

    /**
     * Setter for node's data
     * @param data - character
     */
    public void setData(char data) {
        this.data = data;   //set a node's data
    }

    /**
     * This method is defined to check if a node is a leaf node. If a node's one node and zero node are null and data is
     * not null, it is considered a leaf node.
     * @return - boolean
     */
    public boolean isLeaf() {
        return one == null && zero == null && data != null;     //leaf node properties
    }

    /**
     * This method is defined to check if a node and its descendant nodes are valid nodes. If the node is an internal
     * node, the method is called again for one node and zero node. If a node is a leaf node, it's zero node and
     * one node are meant to be null.
     * @return - boolean
     */
    public boolean isValid() {
        if (isLeaf()){  //if node is a leaf node(at the end of tree)
            return getZero() == null && getOne() == null;   //check if it's one and zero node are null
        }
        else {
            if (getOne() != null && getZero() != null) {    //if it is an internal node
                //check if it's descendant nodes are valid through recursion
                return getZero().isValid() && getOne().isValid();
            }
        }
        return false;   //tree is not valid
    }
}


