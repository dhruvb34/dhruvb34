//Name: Dhruv Barad
//CSCI 1913 Fall 2021
//Project 3 Final
public class HuffmanCodeTree {
    private HuffmanNode root;   //tree's root node

    /**
     * Constructor for Huffman Code Tree
     * @param root - a root node
     */
    public HuffmanCodeTree(HuffmanNode root){
        this.root = root;   //initialize tree's root node
    }

    /**
     * Constructor for the Huffman code tree, provided a codebook. This constructor initializes the root to an empty
     * node. For all the letters in the codebook, 'put' method is called to update the tree.
     * @param codeBook - given codebook
     */
    public HuffmanCodeTree(HuffmanCodeBook codeBook){
        root = new HuffmanNode(null,null);
        for (char c: codeBook.getHuffmanChars()){   //get all the letters from the codebook
            if (codeBook.getSequence(c) == null){   //not adding to the tree if there is no sequence
                return;
            }
            put(codeBook.getSequence(c), c);    //update the tree
        }
    }

    /**
     * This method is defined to check if a tree is valid tree. The tree should only be valid if it has internal nodes
     * and leaf nodes.
     * @return - boolean
     */
    public boolean isValid(){
        return root.isValid();  //call recursive method on the tree's root
    }

    /**
     * This method is defined to update the tree with a binary sequence and a given letter. The addressed node will
     * store the given letter as its data.
     * @param seq - binary sequence
     * @param letter - letter
     */
    public void put(BinarySequence seq, char letter) {
        HuffmanNode node = root;    //start from the root
        for (Boolean b : seq) {     //for each boolean in the given binary sequence
            if (b) {    //if true (or 1)
                if (node.getOne() == null){     //if the next one node is null
                    node.setOne(new HuffmanNode(null,null));    //update the one node with a new one node
                }
                node = node.getOne();   //update the pointer
            }
            else {  //if false(or 0)
                if (node.getZero() == null){    //if the next zero node is null
                    node.setZero(new HuffmanNode(null,null));   //update the one node with a new zero node
                }
                node = node.getZero();  //update the pointer
            }
        }
        node.setData(letter);   //at the end of sequence, update the node's data with given letter
    }

    /**
     * This method is defined to decode a given binary sequence to a string. Method uses a string builder to append
     * a letter. For the binary sequence, the data is only at the node which is a leaf node, and it's added to the string.
     * @param s - a binary sequence
     * @return - decoded string
     */
    public String decode(BinarySequence s){
        HuffmanNode node = root;    //start from the root
        StringBuilder decodedText = new StringBuilder();    //new string builder
        for (Boolean b : s){    //for each boolean in the sequence
            if (b) {    //if true (or 1)
                node = node.getOne();   //update the node's pointer
            } else {    //if false (or 0)
                node = node.getZero();  //update the node's pointer
            }
            if (node.isLeaf()){     //if arrived at a leaf node
                decodedText.append(node.getData()); //add the node's data (a letter) to the string builder
                node = root;    //update the node's pointer to the root again
            }
        }
        return decodedText.toString();  //the decoded string
    }
}

